import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { Observable, Subscription, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators'
import {interval} from 'rxjs';

export  interface RequestInfo{
  jobId: string
  subscriptionId :string
  dtcDellTraceId :string
  offerId  : string
  orgId :string
}

export  interface Message{
  timestamp: string
  description: string
  level: string
}


export class ResponseModel {
  requestInfo:RequestInfo
    messages: Array<Message> 
    status : string
    version :string
    timestamp :string
    output = new Map<String,String>()
    
  constructor(requestInfo:RequestInfo, 
    messages: Array<Message>, 
    status : string,
    version :string,
    timestamp :string){
      this.requestInfo = requestInfo
      this.messages=messages
      this.status = status
      this.version = version
      this.timestamp = timestamp

    }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'url_reader';
  mySubscription!: Subscription

  apiurl= "http://localhost:8123/status"
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  columnsToDisplay = ['requestInfo.job_id', 'status', 'timestamp', 'messages'];
  columnsToDisplayWithExpand = [...this.columnsToDisplay, 'expand'];
  expandedElement: ResponseModel | undefined;

  model:ResponseModel[] = [];
  constructor(private http: HttpClient) { 
    
  }

  ngOnInit() {
    this.mySubscription = interval(1000)
    .subscribe((val) => { console.log('called'); this.loadData() });
  
}


loadData(){
  // this.model = []
  this.http
        .get<ResponseModel[]>(this.apiurl)
        .pipe(retry(1), catchError(this.handleError))
        .subscribe(data => {
          
          if(this.model.length != data.length){
            // new_data:ResponseModel = new ResponseModel({...this.model[0]})
            this.model = data
            // console.log(this.model[0].requestInfo)
            // console.log(typeof data[0])
          }
          // console.log(" model "+JSON.stringify(this.model));
        }
          );
}

// Error handling
handleError(error: any) {
  let errorMessage = '';
  if (error.error instanceof ErrorEvent) {
    // Get client-side error
    errorMessage = error.error.message;
  } else {
    // Get server-side error
    errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
  }
  window.alert(errorMessage);
  return throwError(() => {
    return errorMessage;
  });
}

trackData(index: number, data:ResponseModel) {
  return data.requestInfo.jobId;
}
}
