import { Component, Input, OnInit } from '@angular/core';
import { ResponseModel } from '../app.component';

@Component({
  selector: 'app-row-data',
  templateUrl: './row-data.component.html',
  styleUrls: ['./row-data.component.scss']
})
export class RowDataComponent implements OnInit {

  @Input() 
  responseModel! : ResponseModel

  @Input()
  showMessage = false

  constructor() { }

  ngOnInit(): void {
  }

  handleClick(){
    this.showMessage = !this.showMessage
  }

}
